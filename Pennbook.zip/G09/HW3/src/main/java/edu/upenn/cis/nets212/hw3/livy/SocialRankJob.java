package edu.upenn.cis.nets212.hw3.livy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import org.apache.livy.Job;
import org.apache.livy.JobContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;


import com.amazonaws.services.dynamodbv2.document.AttributeUpdate;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.KeyAttribute;
import com.amazonaws.services.dynamodbv2.document.PrimaryKey;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.ScanOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.TableWriteItems;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.spec.ScanSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.ResourceInUseException;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.mediaconvert.model.Id3Insertion;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.upenn.cis.nets212.storage.SparkConnector;
import edu.upenn.cis.nets212.storage.DynamoConnector;
import scala.Tuple2;
import scala.Tuple3;
// import software.amazon.awssdk.services.dynamodb.model.DynamoDbException;

public class SocialRankJob implements Job<List<MyPair<Integer,Double>>> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Connection to Apache Spark
	 */
	SparkSession spark;
	
	JavaSparkContext context;

	private boolean useBacklinks;

	private String source;

	DynamoDB db;
	Table newsArticlesSearch;
	Table newsArticlesCategory;
	Table friends;
	Table userArticleLikes;
	Table newsArticlesDate;
	Table userCategories;
	Table newsArticlesSuggestion;
	List<String> recentArticles;
	

	/**
	 * Initialize the database connection and open the file
	 * 
	 * @throws IOException
	 * @throws InterruptedException 
	//  * @@ghrowx DynamoDbException 
	 */
	public void initialize() throws IOException, InterruptedException {
		// System.out.println("Connecting to Spark...");
		// spark = SparkConnector.getSparkConnection();
		// context = SparkConnector.getSparkContext();
		
		// System.out.println("Connected!");
		// logger.info("Connecting to DynamoDB...");
		db = DynamoConnector.getConnection("https://dynamodb.us-east-1.amazonaws.com");
		
		spark = SparkConnector.getSparkConnection();
		context = SparkConnector.getSparkContext();
		
		initializeTables();
		
		// logger.debug("Connected!");
		
	}

	// private void initializeTables() throws DynamoDbException, InterruptedException {
	private void initializeTables() throws InterruptedException {
		newsArticlesSearch = db.getTable("news_articles_search");
		newsArticlesCategory = db.getTable("news_articles_category");
		newsArticlesDate = db.getTable("news_articles_date");
		friends = db.getTable("friends");
		userArticleLikes = db.getTable("user_article_likes");
		userCategories = db.getTable("user_categories");
		try {
			newsArticlesSuggestion = db.createTable("news_articles_suggestions",
				Arrays.asList(
					new KeySchemaElement("username", KeyType.HASH),
					new KeySchemaElement("article", KeyType.RANGE)),
				Arrays.asList(
					new AttributeDefinition("username", ScalarAttributeType.S),
					new AttributeDefinition("article", ScalarAttributeType.S)),
				new ProvisionedThroughput(25L, 25L)); // Stay within the free tier
			newsArticlesSuggestion.waitForActive();
		} catch (final ResourceInUseException exists) {
			newsArticlesSuggestion = db.getTable("news_articles_suggestions");
			try {
				System.out.println("Attempting to delete table; please wait...");
				newsArticlesSuggestion.delete();
				newsArticlesSuggestion.waitForDelete();
				System.out.print("Success.");
				newsArticlesSuggestion = db.createTable("news_articles_suggestions",
					Arrays.asList(
						new KeySchemaElement("username", KeyType.HASH),
						new KeySchemaElement("article", KeyType.RANGE)),
					Arrays.asList(
						new AttributeDefinition("username", ScalarAttributeType.S),
						new AttributeDefinition("article", ScalarAttributeType.S)),
					new ProvisionedThroughput(25L, 25L)); // Stay within the free tier
				newsArticlesSuggestion.waitForActive();
			}
			catch (Exception e) {
				System.err.println("Unable to delete table: ");
				System.err.println(e.getMessage());
			}
		}
	}

	public static class Node implements Serializable {
		private static final long serialVersionUID = 1L;
		private String id;
		private String type;
		public String getId() {
			return id;
		}
		public String getType() {
			return type;
		}
		public Node(String newId) {
			this.id = newId;
			if (newId.startsWith("a#")) {
				this.type = "Article";
			} else if (newId.startsWith("c#")) {
				this.type = "Category";
			} else {
				this.type = "User";
			}
		}
		public String toString() { 
			return "Id: " + this.id + " Type: " + this.type;
		}
		@Override
		public int hashCode() {
			return Objects.hash(id, type);
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Node other = (Node) obj;
			return Objects.equals(id, other.id) && Objects.equals(type, other.type);
		} 
		
	}
	

	List<String> getRecentArticleIds() {
		List<String> recentArticlesResult = new LinkedList<>();
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(new Date());
		ItemCollection<QueryOutcome> result = newsArticlesDate.query(new KeyAttribute("pk", date));
		Iterator<Item> iterator = result.iterator();
		while (iterator.hasNext()) {
			recentArticlesResult.add(iterator.next().getString("sk"));
		}
		return recentArticlesResult;
	}

	JavaPairRDD<Node,Node> getFriends() {
		ScanSpec scanSpec = new ScanSpec();
		ItemCollection<ScanOutcome> result = friends.scan(scanSpec);
		List<Tuple2<Node, Node>> edgeList = new LinkedList<Tuple2<Node, Node>>();
		Iterator<Item> iterator = result.iterator();
        while (iterator.hasNext()) {
            // System.out.println(iterator.next().toJSONPretty());
			Item item = iterator.next();
			Tuple2<Node, Node> edge = new Tuple2<Node, Node>(new Node(item.getString("user1")), new Node(item.getString("user2")));
			edgeList.add(edge);
        }
		JavaRDD<Tuple2<Node, Node>> rdd = context.parallelize(edgeList);
		JavaPairRDD<Node, Node> edgePairRdd = JavaPairRDD.fromJavaRDD(rdd);
		return edgePairRdd;
	}

	JavaPairRDD<Node,Node> getUserCategories() {
		ScanSpec scanSpec = new ScanSpec();
		//only changed userCategories
		ItemCollection<ScanOutcome> result = userCategories.scan(scanSpec);
		List<Tuple2<Node, Node>> edgeList = new LinkedList<Tuple2<Node, Node>>();
		Iterator<Item> iterator = result.iterator();
        while (iterator.hasNext()) {
			Item item = iterator.next();
			//changed "pk" "sk"
			Tuple2<Node, Node> edge = new Tuple2<Node, Node>(new Node(item.getString("pk")), new Node(item.getString("sk")));
			edgeList.add(edge);
        }
		JavaRDD<Tuple2<Node, Node>> rdd = context.parallelize(edgeList);
		JavaPairRDD<Node, Node> edgePairRdd = JavaPairRDD.fromJavaRDD(rdd);
		return edgePairRdd;
	}

	JavaPairRDD<Node,Node> getUserArticleLikes() {
		List<Tuple2<Node, Node>> edgeList = new LinkedList<Tuple2<Node, Node>>();
		for (String articleId : recentArticles) {
			QuerySpec querySpec = new QuerySpec()
			.withKeyConditionExpression("pk = :article_id")
				.withValueMap(new ValueMap()
        		.withString(":article_id", articleId));
			ItemCollection<QueryOutcome> result = userArticleLikes.query(querySpec);
			Iterator<Item> iterator = result.iterator();
			while (iterator.hasNext()) {
				Item item = iterator.next();
				//pk is article id, sort key is user
				Tuple2<Node, Node> edge = new Tuple2<Node, Node>(new Node(item.getString("pk")), new Node(item.getString("sk")));
				Tuple2<Node, Node> edge2 = new Tuple2<Node, Node>(new Node(item.getString("sk")), new Node(item.getString("pk")));
				edgeList.add(edge);
				edgeList.add(edge2);
			}
		}
		JavaRDD<Tuple2<Node, Node>> rdd = context.parallelize(edgeList);
		JavaPairRDD<Node, Node> edgePairRdd = JavaPairRDD.fromJavaRDD(rdd);
		return edgePairRdd;
	}

	JavaPairRDD<Node,Node> getUserArticleCategories() {
		List<Tuple2<Node, Node>> edgeList = new LinkedList<Tuple2<Node, Node>>();
		for (String articleId : recentArticles) {
			QuerySpec querySpec = new QuerySpec()
			.withKeyConditionExpression("pk = :article_id")
				.withValueMap(new ValueMap()
        		.withString(":article_id", articleId));

				//only changed newsArticleCategory
			ItemCollection<QueryOutcome> result = newsArticlesCategory.query(querySpec);
			Iterator<Item> iterator = result.iterator();
			while (iterator.hasNext()) {
				Item item = iterator.next();
				//pk is article id, sort key is user
				Tuple2<Node, Node> edge = new Tuple2<Node, Node>(new Node(item.getString("pk")), new Node(item.getString("sk")));
				Tuple2<Node, Node> edge2 = new Tuple2<Node, Node>(new Node(item.getString("sk")), new Node(item.getString("pk")));
				edgeList.add(edge);
				edgeList.add(edge2);
			}
		}
		JavaRDD<Tuple2<Node, Node>> rdd = context.parallelize(edgeList);
		JavaPairRDD<Node, Node> edgePairRdd = JavaPairRDD.fromJavaRDD(rdd);
		return edgePairRdd;
	}
	
	public List<MyPair<Integer,Double>> run() throws IOException, InterruptedException {
		// logger.info("Running");
		
		// // Load the social network
		recentArticles = getRecentArticleIds();
		JavaPairRDD<Node, Node> friendsEdges = getFriends();
		
		JavaPairRDD<Node, Node> userArticleLikesEdges = getUserArticleLikes();
		
		JavaPairRDD<Node, Node> userArticleCategoryEdges = getUserArticleCategories();
		
		JavaPairRDD<Node, Node> userCategoriesEdges = getUserCategories();

		//node1 -> node2
		JavaPairRDD<Node, Node> allEdges = friendsEdges.union(userArticleLikesEdges.union(userArticleCategoryEdges.union(userCategoriesEdges)));

		//node1 <-> (userCount, categoryCount, articleCount)
		JavaPairRDD<Node, Tuple3<Integer, Integer, Integer>> nodeCounts = allEdges.aggregateByKey(new Tuple3<Integer, Integer, Integer>(0, 0, 0),
			(Tuple3<Integer, Integer, Integer> tuple, Node node) -> {
				switch (node.getType()) {
					case "User": {
						return new Tuple3<Integer, Integer, Integer>(tuple._1() + 1, tuple._2(), tuple._3());
					}

					case "Category": {
						return new Tuple3<Integer, Integer, Integer>(tuple._1(), tuple._2() + 1, tuple._3());
					}
					
					case "Article": {
						return new Tuple3<Integer, Integer, Integer>(tuple._1(), tuple._2(), tuple._3() + 1);
					}

					default: {
						throw new IllegalArgumentException("Invalid node type");
					}
				}
				
			},
			(Tuple3<Integer, Integer, Integer> tuple1, Tuple3<Integer, Integer, Integer> tuple2) -> {
				return new Tuple3<Integer, Integer, Integer>(tuple1._1() + tuple2._1(), tuple1._2() + tuple2._2(), tuple1._3() + tuple2._3());
			});
		
		// nodeCounts.foreach(data -> {
		// 	System.out.println("Node1= "+data._1() + " UserNum= " + data._2()._1() + " CategoryNum= " + data._2()._2() + " ArticleNum= " + data._2()._3());
		// });


		//after join: node1 -> (node2 <-> (node1UserCount, node1CategoryCount, node1ArticleCount))
		//after mapToPair: node1 -> (node2, edgeWeight)
		JavaPairRDD<Node, Tuple2<Node, Double>> edgeTransferRDD = allEdges.join(nodeCounts)
			.mapToPair(item -> {
				int node1UserCount = item._2()._2()._1();
				int node1CategoryCount = item._2()._2()._2();
				int node1ArticleCount = item._2()._2()._3();
				Double weight;
				switch (item._1().getType()) {
					case "User": {
						switch (item._2()._1().getType()) {
							case "User": {
								//at least one user to user
								int denom = node1UserCount;
								if (node1CategoryCount == 0 && node1ArticleCount == 0) {
									weight = 1.0 / denom;
								} else if (node1ArticleCount == 0) { //node1CategoryCount != 0
									weight = 0.5 / denom;
								} else if (node1CategoryCount == 0) { //node1ArticleCount != 0
									weight = 0.4286 / denom;
								} else { //both != 0
									weight = 0.3 / denom;
								}
								break;
							}
		
							case "Category": {
								//at least one user to category
								int denom = node1CategoryCount;
								if (node1UserCount == 0 && node1ArticleCount == 0) {
									weight = 1.0 / denom;
								} else if (node1ArticleCount == 0) { //node1UserCount != 0
									weight = 0.5 / denom;
								} else if (node1UserCount == 0) { //node1ArticleCount != 0
									weight = 0.4286 / denom;
								} else { //both != 0
									weight = 0.3 / denom;
								}
								break;
							}
							
							case "Article": {
								//at least one user to article
								int denom = node1ArticleCount;
								if (node1UserCount == 0 && node1CategoryCount == 0) {
									weight = 1.0 / denom;
								} else if (node1CategoryCount == 0) { //node1UserCount != 0
									weight = 0.5714 / denom;
								} else if (node1UserCount == 0) { //node1CategoryCount != 0
									weight = 0.5714 / denom;
								} else { //both != 0
									weight = 0.4 / denom;
								}
								break;
							}
		
							default: {
								throw new IllegalArgumentException("Invalid node type");
							}
						}
						break;
					}

					case "Category": {
						switch (item._2()._1().getType()) {
							case "User": {
								//at least one category to user
								int denom = node1UserCount;
								if (node1ArticleCount == 0) {
									weight = 1.0 / denom;
								} else {
									weight = 0.5 / denom;
								}
								break;
							}
							
							case "Article": {
								//at least one category to article
								int denom = node1ArticleCount;
								if (node1UserCount == 0) {
									weight = 1.0 / denom;
								} else {
									weight = 0.5 / denom;
								}
								break;
							}
		
							default: {
								throw new IllegalArgumentException("Invalid node type");
							}
						}
						break;
					}
					
					case "Article": {
						switch (item._2()._1().getType()) {
							case "User": {
								//at least one article to user
								int denom = node1UserCount;
								if (node1CategoryCount == 0) {
									weight = 1.0 / denom;
								} else {
									weight = 0.5 / denom;
								}
								break;
							}

							case "Category": {
								//at least one article to category
								int denom = node1CategoryCount;
								if (node1UserCount == 0) {
									weight = 1.0 / denom;
								} else {
									weight = 0.5 / denom;
								}
								break;
							}
		
							default: {
								throw new IllegalArgumentException("Invalid node type");
							}
						}
						break;
					}

					default: {
						throw new IllegalArgumentException("Invalid node type");
					}
				}
				return new Tuple2<Node, Tuple2<Node,Double>>(item._1(), new Tuple2<Node, Double>(item._2()._1(), weight));
			});

		//userNode -> (nodeTag, 1.0 starting weight)
		//get all unique users that have edges coming out
		JavaPairRDD<Node, Tuple2<Node, Double>> adsorptionWeights = allEdges.keys()
			.filter((node) -> node.getType().equals("User"))
			.distinct()
			.mapToPair((user) -> new Tuple2<Node, Tuple2<Node, Double>>(user, new Tuple2<Node, Double>(user, 1.0)));
		
		for (int i = 0; i < 15; i++) {
			System.out.println("Iteration: " + i);
			//after join: node1 -> (node2, edge weight), (nodeTag, adsorption weight)
			//after all: node2 -> (nodeTag, adsorption weight * edge weight)
			JavaPairRDD<Node, Tuple2<Node, Double>> propogateRDD = edgeTransferRDD.join(adsorptionWeights)
				.mapToPair((item) -> new Tuple2<Node, Tuple2<Node, Double>>(item._2()._1()._1(),
					new Tuple2<Node, Double>(item._2()._2()._1(), item._2()._1()._2() * item._2()._2()._2())));
			
			// System.out.println(propogateRDD.collect());

			//maptoPair: (node1, node2) -> (sum, count)
			JavaPairRDD<Node, Tuple2<Node, Double>> adsorptionWeights2 = propogateRDD
				.mapToPair((item) -> {
					if (item._1().getType().equals("User") && item._1().equals(item._2()._1())) {
						//check if user has its own tag, set to 1.0 to avoid washout
						return new Tuple2<Tuple2<Node, Node>, Tuple2<Double, Integer>>(
							new Tuple2<Node, Node>(item._1(), item._2()._1()), 
							new Tuple2<Double, Integer>(1.0, 1));
					} else {
						return new Tuple2<Tuple2<Node, Node>, Tuple2<Double, Integer>>(
							new Tuple2<Node, Node>(item._1(), item._2()._1()), 
							new Tuple2<Double, Integer>(item._2()._2(), 1));
					}
					
				})
				.reduceByKey((a, b) -> new Tuple2<Double, Integer>(a._1() + b._1(), a._2() + b._2()))
				.mapToPair((item) -> new Tuple2<Node, Tuple2<Node, Double>>(
					item._1()._1(),
					new Tuple2<Node, Double>(item._1()._2(), item._2()._1() / item._2()._2())));
			
			//add filter for very small values to make it run faster
			adsorptionWeights = adsorptionWeights2;
		}

		adsorptionWeights = adsorptionWeights.filter((tuple) -> tuple._1().getType().equals("Article") && tuple._2()._1().getType().equals("User"));

		//write to database
		List<Item> batchItemsAdsorptionWeights = new ArrayList<Item>();
		adsorptionWeights.collect().stream().forEach((tuple) -> {
			Item item = new Item()
				.withPrimaryKey("username", tuple._2()._1().getId(), "article", tuple._1().getId())
				.withDouble("weight", tuple._2()._2())
				.withBoolean("recommended", false);
			batchItemsAdsorptionWeights.add(item);
			if (batchItemsAdsorptionWeights.size() > 22) {
				TableWriteItems newsArticlesSuggestionTableWriteItems = new TableWriteItems("news_articles_suggestions")
					.withItemsToPut(batchItemsAdsorptionWeights);
				db.batchWriteItem(newsArticlesSuggestionTableWriteItems);
				batchItemsAdsorptionWeights.clear();
			}
		});
		if (!batchItemsAdsorptionWeights.isEmpty()) {
			TableWriteItems tableWriteItems = new TableWriteItems("news_articles_suggestions")
					.withItemsToPut(batchItemsAdsorptionWeights);
			db.batchWriteItem(tableWriteItems);
		}
		return new ArrayList<MyPair<Integer,Double>>();
	}
	
	public SocialRankJob() {
		System.setProperty("file.encoding", "UTF-8");
		
		// this.useBacklinks = useBacklinks;
		// this.source = source;
	}

	@Override
	public List<MyPair<Integer,Double>> call(JobContext arg0) throws Exception {
		initialize();
		return run();
	}

}
