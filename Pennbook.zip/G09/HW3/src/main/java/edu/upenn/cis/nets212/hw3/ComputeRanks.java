package edu.upenn.cis.nets212.hw3;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;

import edu.upenn.cis.nets212.config.Config;
import edu.upenn.cis.nets212.storage.SparkConnector;
import scala.Tuple2;

public class ComputeRanks {
	/**
	 * The basic logger
	 */
	static Logger logger = LogManager.getLogger(ComputeRanks.class);

	/**
	 * Connection to Apache Spark
	 */
	SparkSession spark;
	
	JavaSparkContext context;

	private int dMax;

	private int iMax;

	private boolean debug;
	
	public ComputeRanks(int dMax, int iMax, boolean debug) {
		System.setProperty("file.encoding", "UTF-8");
		this.dMax = dMax;
		this.iMax = iMax;
		this.debug = debug;
	}

	/**
	 * Initialize the database connection and open the file
	 * 
	 * @throws IOException
	 * @throws InterruptedException 
	 */
	public void initialize() throws IOException, InterruptedException {
		logger.info("Connecting to Spark...");

		spark = SparkConnector.getSparkConnection();
		context = SparkConnector.getSparkContext();
		
		logger.debug("Connected!");
	}
	
	/**
	 * Fetch the social network from the S3 path, and create a (followed, follower) edge graph
	 * 
	 * @param filePath
	 * @return JavaPairRDD: (followed: int, follower: int)
	 */
	JavaPairRDD<Integer,Integer> getSocialNetwork(String filePath) {

		JavaRDD<String[]> file = context.textFile(filePath, Config.PARTITIONS)
				.map(line -> {
					if (line.contains(" ")) {
						return line.toString().split(" ");
					} else {
						return line.toString().split("\t");
					}
				});
		JavaPairRDD<Integer, Integer> followedFollowerPairs = file.mapToPair(row -> new Tuple2<Integer,Integer>(Integer.parseInt(row[0]), Integer.parseInt(row[1])));
		return followedFollowerPairs.distinct();
	}
	
	private JavaRDD<Integer> getSinks(JavaPairRDD<Integer,Integer> network) {
		JavaRDD<Integer> nodes = network.keys().union(network.values()).distinct(); //all nodes
		JavaRDD<Integer> sourceNodes = network.keys().distinct();
		JavaRDD<Integer> sinks = nodes.subtract(sourceNodes);
		return sinks;
	}

	/**
	 * Main functionality in the program: read and process the social network
	 * 
	 * @throws IOException File read, network, and other errors
	 * @throws InterruptedException User presses Ctrl-C
	 */
	public void run() throws IOException, InterruptedException {
		logger.info("Running");

		// Load the social network
		// followed, follower
		JavaPairRDD<Integer, Integer> network = getSocialNetwork(Config.SOCIAL_NET_PATH);
		JavaRDD<Integer> nodes = network.keys().union(network.values()).distinct();
		System.out.println("This graph contains " + nodes.count() + " nodes and "+ network.count() + " edges");
		
		//find sinks
		JavaRDD<Integer> sinks = getSinks(network);
		
		//add sinks
		JavaPairRDD<Integer, Integer> backEdges = sinks.mapToPair(node -> new Tuple2<Integer, Integer>(node, node));
		JavaPairRDD<Integer, Tuple2<Integer, Integer>> backEdgesRepeatedPair = network.mapToPair(pair -> pair.swap()).join(backEdges);
		JavaPairRDD<Integer, Integer> backEdgesRepeated = backEdgesRepeatedPair.mapToPair(pair -> new Tuple2<Integer, Integer>(pair._1, pair._2._1));
		network = network.union(backEdgesRepeated);
		System.out.println("Added " + backEdgesRepeated.count() + " backlinks");

		//initialize PageRank
		JavaPairRDD<Integer,Integer> nodeFollowerCounts = network.aggregateByKey(0, 
				(val,row) -> val + 1,
				(val,val2) -> val+val2);
		JavaPairRDD<Integer, Double> nodeTransfer = nodeFollowerCounts.mapToPair(pair -> {
			double inverseNumEdges = 1.0 / pair._2();
			return new Tuple2<Integer, Double>(pair._1(), inverseNumEdges);
		});
		JavaPairRDD<Integer, Tuple2<Integer, Double>> edgeTransfer = network.join(nodeTransfer);
		edgeTransfer.foreach(pair -> {
			System.out.println(pair._1() + " , " + pair._2()._1()  + " , " +  pair._2()._2());
		});
		
		//iteration
		double d = 0.15; //decay factor
		JavaPairRDD<Integer, Double> pageRank = nodes.mapToPair(node -> new Tuple2<Integer, Double>(node, 1.0));
		for (int i = 0; i < iMax; i++) {
			JavaPairRDD<Integer, Double> propogate = edgeTransfer
					.join(pageRank)
					.mapToPair(item -> new Tuple2<Integer, Double>(item._2._1._1, item._2._2 * item._2._1._2));
			JavaPairRDD<Integer, Double> pageRank2 = propogate
					.reduceByKey((a, b) -> a + b)
					.mapToPair(item -> new Tuple2<Integer, Double>(item._1, d + (1-d) * item._2));
			
			//calculate max diff
			JavaRDD<Double> differences = pageRank.join(pageRank2).map(item -> Math.abs(item._2._1 - item._2._2));
			double maxDiff = differences.reduce((a, b) -> Math.max(a, b));
			pageRank = pageRank2;
			
			
			
			//check if maxDiff too small
			if (maxDiff <= dMax) {
				break;
			}
			
		}
		
		// display top 10
		if (debug) {
			pageRank.foreach(pair -> System.out.println(pair._1 + " " + pair._2));
		} else {
			JavaPairRDD<Integer, Double> sortedPageRank = pageRank.mapToPair(pair -> pair.swap()).sortByKey(false).mapToPair(pair -> pair.swap());
			List<Tuple2<Integer, Double>> top10 = sortedPageRank.take(10);
			System.out.println("Top 10: ");
			for (Tuple2<Integer, Double> tuple : top10) {
				System.out.println(tuple._1 + ", " + tuple._2);
			}
		}
		

		logger.info("*** Finished social network ranking! ***");
	}


	/**
	 * Graceful shutdown
	 */
	public void shutdown() {
		logger.info("Shutting down");

		if (spark != null)
			spark.close();
	}
	
	

	public static void main(String[] args) {
		int dMax = 30;
		int iMax = 25;
		boolean debug = false;
		if (args.length >= 1) {
			dMax = Integer.parseInt(args[0]);
		}
		if (args.length >= 2) {
			iMax = Integer.parseInt(args[1]);
		}
		if (args.length >= 3) {
			debug = true;
		}
		final ComputeRanks cr = new ComputeRanks(dMax, iMax, debug);

		try {
			cr.initialize();

			cr.run();
		} catch (final IOException ie) {
			logger.error("I/O error: ");
			ie.printStackTrace();
		} catch (final InterruptedException e) {
			e.printStackTrace();
		} finally {
			cr.shutdown();
		}
	}

}
