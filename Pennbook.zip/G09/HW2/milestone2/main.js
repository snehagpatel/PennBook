/**
 * 
 */

var port = 8081;

const express = require('express');
const app = new express();
const path = require("path");
const JSON5 = require("json5")
const stemmer = require("stemmer")

const AWS = require("aws-sdk");

const {DynamoDB, QueryCommand} = require('@aws-sdk/client-dynamodb-v2-node');

AWS.config.update({region:'us-east-1'});

const client = new AWS.DynamoDB();

app.set("view engine", "pug");
app.set("views", path.join(__dirname, "views"))

app.get('/', function(request, response) {
    response.sendFile('html/index.html', { root: __dirname });
});

const stopWordsList = ["a", "all", "any", "but", "the"];

function clean(token, stopWordsList) {
	//clean word, only alphabetical chars allowed
	token = token.trim();
	if (token.match("[a-zA-Z]+")) {
		var lCaseToken = token.toLowerCase();
		if (!(stopWordsList.includes(lCaseToken))) {
			lCaseTokenStemmed = stemmer(lCaseToken);
			return lCaseTokenStemmed;
		}
	} else {
		return null;
	}
}

function serialize(talk) {
	numQuotes = talk.related_talks.replace(/([0-9-]+):/g, "\"$1\":")
	embedUrl = talk.url.replace("www.ted.com", "embed.ted.com")
	return {
		"talk_id": talk.talk_id,
		"speaker_1": talk.speaker_1,
		"title": talk.title,
		"url": talk.url,
		"embed_url": embedUrl,
		"social_id": talk.social_id,
		"views": talk.views,
		"duration": talk.duration,
		"description": talk.description,
		"topics": JSON5.parse(talk.topics),
		"related_talks": JSON5.parse(numQuotes)
	}
}

app.get('/talk', function(request, response) {
	var docClient = new AWS.DynamoDB.DocumentClient();
	var talkId = parseInt(request.query.id)
	//get promises of all queries of each word
	if (!talkId) {
		console.log("Id is not a number, id is: " + request.query.id)
	} else {
		var promises = [];
		var params = {
		  	TableName: 'ted_talks',
			KeyConditionExpression: '#talk_id = :talk_id',
			ExpressionAttributeNames: {
		    	'#talk_id': "talk_id"
			},
			ExpressionAttributeValues: {
		    	':talk_id': talkId
			},
			Limit: 1
		};
		promises.push(docClient.query(params).promise());
		//when all promises return, display results
		Promise.all(promises).then(function(promises) {
			var talks = [];
			promises.forEach(promise => {
				promise.Items.forEach(talk => {
					talks.push(serialize(talk));
				});
			});
			response.render("results", { "query": request.query.id, "talks": talks });
		});
	}
});

app.get('/talks', function(request, response) {
	var docClient = new AWS.DynamoDB.DocumentClient();
	//split word into array of words by whitespace
	var words = request.query.keyword.split(/[ ]+/);
	//get promises of all queries of each word
	var promises = [];
	words = words.map(word => {
		const cleanedWord = clean(word, stopWordsList);
		if (cleanedWord) {
			var params = {
			  	TableName: 'inverted',
				KeyConditionExpression: '#keyword = :keyword',
				ExpressionAttributeNames: {
			    '#keyword': "keyword"
				},
				ExpressionAttributeValues: {
			    ':keyword': cleanedWord
				},
				Limit: 15
			};
			promises.push(docClient.query(params).promise());
		}
	});
	//when all promises return, display results
	var inxids = new Set();
	Promise.all(promises).then(function(promises) {
		promises.forEach(promise => {
			promise.Items.forEach(entry => {
				inxids.add(entry.inxid);
			});
		});
	}).then(function() {
		var promiseTalks = [];
		for (let inxid of inxids) {
			var params = {
			  	TableName: 'ted_talks',
				KeyConditionExpression: '#talk_id = :talk_id',
				ExpressionAttributeNames: {
			    	'#talk_id': "talk_id"
				},
				ExpressionAttributeValues: {
			    	':talk_id': inxid
				},
				Limit: 1
			};
			//don't display more than 15 talks
			if (promiseTalks.length >= 15) {
				break;
			}
			promiseTalks.push(docClient.query(params).promise());
		}
		//when all promises return, display results
		Promise.all(promiseTalks).then(function(promises) {
			var talks = [];
			promises.forEach(promise => {
				promise.Items.forEach(talk => {
					talks.push(serialize(talk));
				});
			});
			response.render("results", { "query": request.query.keyword, "talks": talks});
		});
	});
});

app.listen(port, () => {
  console.log(`HW2 app listening at http://localhost:${port}`)
})
