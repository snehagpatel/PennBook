package edu.upenn.cis.nets212.hw2.livy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import org.apache.livy.Job;
import org.apache.livy.JobContext;
import org.apache.hadoop.mapreduce.ID;
// import org.apache.logging.log4j.LogManager;
// import org.apache.logging.log4j.Logger;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema;
import org.apache.spark.sql.types.StructType;

import com.amazonaws.services.dynamodbv2.document.AttributeUpdate;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.KeyAttribute;
import com.amazonaws.services.dynamodbv2.document.PrimaryKey;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.ScanOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.TableWriteItems;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.spec.ScanSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.ResourceInUseException;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.mediaconvert.model.Id3Insertion;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
// import com.opencsv.CSVParser;
// import com.opencsv.CSVReader;
// import com.opencsv.exceptions.CsvValidationException;

import edu.upenn.cis.nets212.config.Config;
import edu.upenn.cis.nets212.storage.DynamoConnector;
import edu.upenn.cis.nets212.storage.SparkConnector;
// import opennlp.tools.stemmer.PorterStemmer;
// import opennlp.tools.stemmer.Stemmer;
// import opennlp.tools.tokenize.SimpleTokenizer;
import scala.Tuple2;
import scala.Tuple3;
import software.amazon.awssdk.services.dynamodb.model.DynamoDbException;

public class LoadNetworkJob implements Job<Integer>{
	/**
	 * The basic logger
	 */
	// static Logger logger = LogManager.getLogger(LoadNetworkJob.class);

	/**
	 * Connection to DynamoDB
	 */
	DynamoDB db;
	Table newsArticlesSearch;
	Table newsArticlesCategory;
	Table friends;
	Table userArticleLikes;
	Table newsArticlesDate;
	Table userCategories;
	Table newsArticlesSuggestion;
	List<String> recentArticles;
	// CSVParser parser;
	
	
	/**
	 * Connection to Apache Spark
	 */
	SparkSession spark;
	
	JavaSparkContext context;

	// SimpleTokenizer model;

	List<String> stopWordsList; 

	// Stemmer stemmer;
	
	/**
	 * Helper function: swap key and value in a JavaPairRDD
	 * 
	 * @author zives
	 *
	 */
	static class SwapKeyValue<T1,T2> implements PairFunction<Tuple2<T1,T2>, T2,T1> {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public Tuple2<T2, T1> call(Tuple2<T1, T2> t) throws Exception {
			return new Tuple2<>(t._2, t._1);
		}
		
	}
	
	public LoadNetworkJob() {
		System.setProperty("file.encoding", "UTF-8");
		// parser = new CSVParser();
		// model = SimpleTokenizer.INSTANCE;
		String[] stopWords = {"a", "all", "any", "but", "the"};
		stopWordsList = Arrays.asList(stopWords);
		// stemmer = new PorterStemmer();
	}

	public static class ArticlePOJO {
		private String category;
		private String headline;
		private String authors;
		private String link;
		private String date;
		@JsonIgnore
		private String id;
		
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public String getHeadline() {
			return headline;
		}
		public void setHeadline(String headline) {
			this.headline = headline;
		}
		public String getAuthors() {
			return authors;
		}
		public void setAuthors(String authors) {
			this.authors = authors;
		}
		public String getLink() {
			return link;
		}
		public void setLink(String link) {
			this.link = link;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
	}
	
	private void initializeTables() throws DynamoDbException, InterruptedException {
		boolean writeNewsArticlesSearch = false;
		boolean writeNewsArticlesCategory = false;
		boolean writeNewsArticlesDate = false;
		try {
			newsArticlesSearch = db.createTable("news_articles_search",
				Arrays.asList(
					new KeySchemaElement("pk", KeyType.HASH),
					new KeySchemaElement("sk", KeyType.RANGE)),
				Arrays.asList(
					new AttributeDefinition("pk", ScalarAttributeType.S),
					new AttributeDefinition("sk", ScalarAttributeType.S)),
				new ProvisionedThroughput(25L, 25L)); // Stay within the free tier
			newsArticlesSearch.waitForActive();
			writeNewsArticlesSearch = true;
		} catch (final ResourceInUseException exists) {
			newsArticlesSearch = db.getTable("news_articles_search");
		}
		try {
			newsArticlesCategory = db.createTable("news_articles_category",
				Arrays.asList(
					new KeySchemaElement("pk", KeyType.HASH),
					new KeySchemaElement("sk", KeyType.RANGE)),
				Arrays.asList(
					new AttributeDefinition("pk", ScalarAttributeType.S),
					new AttributeDefinition("sk", ScalarAttributeType.S)),
				new ProvisionedThroughput(25L, 25L)); // Stay within the free tier
			newsArticlesCategory.waitForActive();
			writeNewsArticlesCategory = true;
		} catch (final ResourceInUseException exists) {
			newsArticlesCategory = db.getTable("news_articles_category");
		}

		try {
			newsArticlesDate = db.createTable("news_articles_date",
				Arrays.asList(
					new KeySchemaElement("pk", KeyType.HASH),
					new KeySchemaElement("sk", KeyType.RANGE)),
				Arrays.asList(
					new AttributeDefinition("pk", ScalarAttributeType.S),
					new AttributeDefinition("sk", ScalarAttributeType.S)),
				new ProvisionedThroughput(25L, 25L)); // Stay within the free tier
			newsArticlesDate.waitForActive();
			writeNewsArticlesDate = true;
		} catch (final ResourceInUseException exists) {
			newsArticlesDate = db.getTable("news_articles_date");
		}

		//load in articles and word pairs

		// logger.info(writeNewsArticlesSearch);
		// logger.info(writeNewsArticlesCategory);
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(new File(Config.NEWS_PATH)));
			int id = 0;
			List<Item> batchItemsNewsArticlesCategory = new ArrayList<Item>();
			List<Item> batchItemsNewsArticlesDate = new ArrayList<Item>();
			for (String line = br.readLine(); line != null; line = br.readLine()) {
				ObjectMapper mapper = new ObjectMapper()
					.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				try {
					// JSON string to Java object
					ArticlePOJO articlePOJO = mapper.readValue(line, ArticlePOJO.class);
					articlePOJO.setId("a#" + String.valueOf(id));
					articlePOJO.setCategory("c#" + articlePOJO.getCategory());
					//add year to date
					articlePOJO.setDate(addYear(articlePOJO.getDate()));
					if (writeNewsArticlesSearch) { 
						writeArticlePOJONewsArticlesSearch(articlePOJO);
					}
					if (writeNewsArticlesCategory) {
						writeArticlePOJONewsArticlesCategory(articlePOJO, batchItemsNewsArticlesCategory);
					}
					if (writeNewsArticlesDate) {
						writeArticlePOJONewsArticlesDate(articlePOJO, batchItemsNewsArticlesDate);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
				id++;
				if (id > 10) {
					break;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		friends = db.getTable("friends");
		userArticleLikes = db.getTable("user_article_likes");
		userCategories = db.getTable("user_categories");
		try {
			newsArticlesSuggestion = db.createTable("news_articles_suggestions",
				Arrays.asList(
					new KeySchemaElement("username", KeyType.HASH),
					new KeySchemaElement("article", KeyType.RANGE)),
				Arrays.asList(
					new AttributeDefinition("username", ScalarAttributeType.S),
					new AttributeDefinition("article", ScalarAttributeType.S)),
				new ProvisionedThroughput(25L, 25L)); // Stay within the free tier
			newsArticlesSuggestion.waitForActive();
		} catch (final ResourceInUseException exists) {
			newsArticlesSuggestion = db.getTable("news_articles_suggestions");
			try {
				System.out.println("Attempting to delete table; please wait...");
				newsArticlesSuggestion.delete();
				newsArticlesSuggestion.waitForDelete();
				System.out.print("Success.");
				newsArticlesSuggestion = db.createTable("news_articles_suggestions",
					Arrays.asList(
						new KeySchemaElement("username", KeyType.HASH),
						new KeySchemaElement("article", KeyType.RANGE)),
					Arrays.asList(
						new AttributeDefinition("username", ScalarAttributeType.S),
						new AttributeDefinition("article", ScalarAttributeType.S)),
					new ProvisionedThroughput(25L, 25L)); // Stay within the free tier
				newsArticlesSuggestion.waitForActive();
			}
			catch (Exception e) {
				System.err.println("Unable to delete table: ");
				System.err.println(e.getMessage());
			}
			
		}
	}

	private String addYear(String date) {
		String newYear = String.valueOf(Integer.parseInt(date.substring(0, 4)) + 4);
		String newDate = newYear + date.substring(4, date.length());
		System.out.println(newDate);
		return newDate;
	};

	private void writeArticlePOJONewsArticlesCategory(ArticlePOJO articlePOJO,  List<Item> batchItemsNewsArticlesCategory) {
		Item item = new Item()
			.withPrimaryKey("pk", articlePOJO.getId(), "sk", articlePOJO.getCategory());
		Item item2 = new Item()
			.withPrimaryKey("pk", articlePOJO.getCategory(), "sk", articlePOJO.getId());
		batchItemsNewsArticlesCategory.add(item);
		batchItemsNewsArticlesCategory.add(item2);
		if (batchItemsNewsArticlesCategory.size() > 22) {
			TableWriteItems newsArticlesCategoryTableWriteItems = new TableWriteItems("news_articles_category")
				.withItemsToPut(batchItemsNewsArticlesCategory);
			db.batchWriteItem(newsArticlesCategoryTableWriteItems);
			batchItemsNewsArticlesCategory.clear();
		}
		if (!batchItemsNewsArticlesCategory.isEmpty()) {
			TableWriteItems tableWriteItems = new TableWriteItems("news_articles_category")
					.withItemsToPut(batchItemsNewsArticlesCategory);
			db.batchWriteItem(tableWriteItems);
		}
	}

	private void writeArticlePOJONewsArticlesDate(ArticlePOJO articlePOJO,  List<Item> batchItemsNewsArticlesDate) {
		Item item = new Item()
			.withPrimaryKey("pk", articlePOJO.getDate(), "sk", articlePOJO.getId());
		// Item item2 = new Item()
		// 	.withPrimaryKey("pk", articlePOJO.getCategory(), "sk", articlePOJO.getId());
		batchItemsNewsArticlesDate.add(item);
		if (batchItemsNewsArticlesDate.size() > 22) {
			TableWriteItems newsArticlesDateTableWriteItems = new TableWriteItems("news_articles_date")
				.withItemsToPut(batchItemsNewsArticlesDate);
			db.batchWriteItem(newsArticlesDateTableWriteItems);
			batchItemsNewsArticlesDate.clear();
		}
		if (!batchItemsNewsArticlesDate.isEmpty()) {
			TableWriteItems tableWriteItems = new TableWriteItems("news_articles_date")
					.withItemsToPut(batchItemsNewsArticlesDate);
			db.batchWriteItem(tableWriteItems);
		}
	}

	private void writeArticlePOJONewsArticlesSearch(ArticlePOJO articlePOJO) {
		// //tokenize headlines
		
		// Set<String> words = new HashSet<String>();
		// String[] tokens = model.tokenize(articlePOJO.getHeadline());
		// for (String token : tokens) {
		// 	if (cleanWord(token, stopWordsList) != null) {
		// 		words.add(cleanWord(token, stopWordsList));
		// 	}
		// }
		// //write item to db
		// // new AttributeDefinition("article_id", ScalarAttributeType.N),
		// 			// new AttributeDefinition("category", ScalarAttributeType.S),
		// 			// new AttributeDefinition("headline", ScalarAttributeType.S),
		// 			// new AttributeDefinition("authors", ScalarAttributeType.S),
		// 			// new AttributeDefinition("link", ScalarAttributeType.S),
		// 			// new AttributeDefinition("date", ScalarAttributeType.S)),
		// List<Item> batchItems = new ArrayList<Item>();
		// for (String word: words) {
		// 	word = "w#" + word;
		// 	Item item = new Item()
		// 		.withPrimaryKey("pk", word, "sk", articlePOJO.getId())
		// 		.withString("category", articlePOJO.getCategory())
		// 		.withString("headline", articlePOJO.getHeadline())
		// 		.withString("authors", articlePOJO.getAuthors())
		// 		.withString("link", articlePOJO.getLink())
		// 		.withString("date", articlePOJO.getDate());
		// 	Item item2 = new Item()
		// 		.withPrimaryKey("pk", articlePOJO.getId(), "sk", word)
		// 		.withString("word", word)
		// 		.withString("category", articlePOJO.getCategory())
		// 		.withString("headline", articlePOJO.getHeadline())
		// 		.withString("authors", articlePOJO.getAuthors())
		// 		.withString("link", articlePOJO.getLink())
		// 		.withString("date", articlePOJO.getDate());
		// 	batchItems.add(item);
		// 	batchItems.add(item2);
		// 	if (batchItems.size() > 22) {
		// 		TableWriteItems iindexTableWriteItems = new TableWriteItems("news_articles_search")
		// 			.withItemsToPut(batchItems);
		// 		db.batchWriteItem(iindexTableWriteItems);
		// 		batchItems.clear();
		// 	}
		// }
		// if (!batchItems.isEmpty()) {
		// 	TableWriteItems iindexTableWriteItems = new TableWriteItems("news_articles_search")
		// 			.withItemsToPut(batchItems);
		// 	db.batchWriteItem(iindexTableWriteItems);
		// }
	}

	// private String cleanWord(String token, List<String> stopWordsList) {
	// 	if (token.matches("[a-zA-Z]+")) {
	// 		String lCaseToken = token.toLowerCase();
	// 		if (!(stopWordsList.contains(lCaseToken))) {
	// 			String lCaseTokenStemmed = stemmer.stem(lCaseToken).toString();
	// 			return lCaseTokenStemmed;
	// 		}
	// 	}
	// 	return null;
	// }


	/**
	 * Initialize the database connection and open the file
	 * 
	 * @throws IOException
	 * @throws InterruptedException 
	 * @throws DynamoDbException 
	 */
	public void initialize() throws IOException, DynamoDbException, InterruptedException {
		// logger.info("Connecting to DynamoDB...");
		db = DynamoConnector.getConnection(Config.DYNAMODB_URL);
		
		spark = SparkConnector.getSparkConnection();
		context = SparkConnector.getSparkContext();
		
		initializeTables();
		
		// logger.debug("Connected!");
	}
	
	public static class Node implements Serializable {
		private static final long serialVersionUID = 1L;
		private String id;
		private String type;
		public String getId() {
			return id;
		}
		public String getType() {
			return type;
		}
		public Node(String newId) {
			this.id = newId;
			if (newId.startsWith("a#")) {
				this.type = "Article";
			} else if (newId.startsWith("c#")) {
				this.type = "Category";
			} else {
				this.type = "User";
			}
		}
		public String toString() { 
			return "Id: " + this.id + " Type: " + this.type;
		}
		@Override
		public int hashCode() {
			return Objects.hash(id, type);
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Node other = (Node) obj;
			return Objects.equals(id, other.id) && Objects.equals(type, other.type);
		} 
		
	}
	

	List<String> getRecentArticleIds() {
		List<String> recentArticlesResult = new LinkedList<>();
		ItemCollection<QueryOutcome> result = newsArticlesDate.query(new KeyAttribute("pk", "2018-05-26"));//TODO: hardcoded date
		Iterator<Item> iterator = result.iterator();
		while (iterator.hasNext()) {
			recentArticlesResult.add(iterator.next().getString("sk"));
		}
		return recentArticlesResult;
	}

	JavaPairRDD<Node,Node> getFriends() {
		ScanSpec scanSpec = new ScanSpec();
		ItemCollection<ScanOutcome> result = friends.scan(scanSpec);
		List<Tuple2<Node, Node>> edgeList = new LinkedList<Tuple2<Node, Node>>();
		Iterator<Item> iterator = result.iterator();
        while (iterator.hasNext()) {
            // System.out.println(iterator.next().toJSONPretty());
			Item item = iterator.next();
			Tuple2<Node, Node> edge = new Tuple2<Node, Node>(new Node(item.getString("user1")), new Node(item.getString("user2")));
			edgeList.add(edge);
        }
		JavaRDD<Tuple2<Node, Node>> rdd = context.parallelize(edgeList);
		JavaPairRDD<Node, Node> edgePairRdd = JavaPairRDD.fromJavaRDD(rdd);
		return edgePairRdd;
	}

	JavaPairRDD<Node,Node> getUserCategories() {
		ScanSpec scanSpec = new ScanSpec();
		//only changed userCategories
		ItemCollection<ScanOutcome> result = userCategories.scan(scanSpec);
		List<Tuple2<Node, Node>> edgeList = new LinkedList<Tuple2<Node, Node>>();
		Iterator<Item> iterator = result.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next().toJSONPretty());
			Item item = iterator.next();
			//changed "pk" "sk"
			Tuple2<Node, Node> edge = new Tuple2<Node, Node>(new Node(item.getString("pk")), new Node(item.getString("sk")));
			edgeList.add(edge);
        }
		JavaRDD<Tuple2<Node, Node>> rdd = context.parallelize(edgeList);
		JavaPairRDD<Node, Node> edgePairRdd = JavaPairRDD.fromJavaRDD(rdd);
		return edgePairRdd;
	}

	JavaPairRDD<Node,Node> getUserArticleLikes() {
		List<Tuple2<Node, Node>> edgeList = new LinkedList<Tuple2<Node, Node>>();
		for (String articleId : recentArticles) {
			QuerySpec querySpec = new QuerySpec()
			.withKeyConditionExpression("pk = :article_id")
				.withValueMap(new ValueMap()
        		.withString(":article_id", articleId));
			ItemCollection<QueryOutcome> result = userArticleLikes.query(querySpec);
			Iterator<Item> iterator = result.iterator();
			while (iterator.hasNext()) {
				Item item = iterator.next();
				//pk is article id, sort key is user
				Tuple2<Node, Node> edge = new Tuple2<Node, Node>(new Node(item.getString("pk")), new Node(item.getString("sk")));
				Tuple2<Node, Node> edge2 = new Tuple2<Node, Node>(new Node(item.getString("sk")), new Node(item.getString("pk")));
				edgeList.add(edge);
				edgeList.add(edge2);
			}
		}
		JavaRDD<Tuple2<Node, Node>> rdd = context.parallelize(edgeList);
		JavaPairRDD<Node, Node> edgePairRdd = JavaPairRDD.fromJavaRDD(rdd);
		return edgePairRdd;
	}

	JavaPairRDD<Node,Node> getUserArticleCategories() {
		List<Tuple2<Node, Node>> edgeList = new LinkedList<Tuple2<Node, Node>>();
		for (String articleId : recentArticles) {
			QuerySpec querySpec = new QuerySpec()
			.withKeyConditionExpression("pk = :article_id")
				.withValueMap(new ValueMap()
        		.withString(":article_id", articleId));

				//only changed newsArticleCategory
			ItemCollection<QueryOutcome> result = newsArticlesCategory.query(querySpec);
			Iterator<Item> iterator = result.iterator();
			while (iterator.hasNext()) {
				Item item = iterator.next();
				//pk is article id, sort key is user
				Tuple2<Node, Node> edge = new Tuple2<Node, Node>(new Node(item.getString("pk")), new Node(item.getString("sk")));
				Tuple2<Node, Node> edge2 = new Tuple2<Node, Node>(new Node(item.getString("sk")), new Node(item.getString("pk")));
				edgeList.add(edge);
				edgeList.add(edge2);
			}
		}
		JavaRDD<Tuple2<Node, Node>> rdd = context.parallelize(edgeList);
		JavaPairRDD<Node, Node> edgePairRdd = JavaPairRDD.fromJavaRDD(rdd);
		return edgePairRdd;
	}

	/**
	 * Main functionality in the program: read and process the social network
	 * 
	 * @throws IOException File read, network, and other errors
	 * @throws DynamoDbException DynamoDB is unhappy with something
	 * @throws InterruptedException User presses Ctrl-C
	 */
	public Integer run() throws IOException, DynamoDbException, InterruptedException {
		// logger.info("Running");
		
		// // Load the social network
		recentArticles = getRecentArticleIds();
		JavaPairRDD<Node, Node> friendsEdges = getFriends();
		System.out.println(friendsEdges.collect());
		
		JavaPairRDD<Node, Node> userArticleLikesEdges = getUserArticleLikes();
		
		JavaPairRDD<Node, Node> userArticleCategoryEdges = getUserArticleCategories();
		
		JavaPairRDD<Node, Node> userCategoriesEdges = getUserCategories();

		//node1 -> node2
		JavaPairRDD<Node, Node> allEdges = friendsEdges.union(userArticleLikesEdges.union(userArticleCategoryEdges.union(userCategoriesEdges)));

		//node1 <-> (userCount, categoryCount, articleCount)
		JavaPairRDD<Node, Tuple3<Integer, Integer, Integer>> nodeCounts = allEdges.aggregateByKey(new Tuple3<Integer, Integer, Integer>(0, 0, 0),
			(Tuple3<Integer, Integer, Integer> tuple, Node node) -> {
				switch (node.getType()) {
					case "User": {
						return new Tuple3<Integer, Integer, Integer>(tuple._1() + 1, tuple._2(), tuple._3());
					}

					case "Category": {
						return new Tuple3<Integer, Integer, Integer>(tuple._1(), tuple._2() + 1, tuple._3());
					}
					
					case "Article": {
						return new Tuple3<Integer, Integer, Integer>(tuple._1(), tuple._2(), tuple._3() + 1);
					}

					default: {
						throw new IllegalArgumentException("Invalid node type");
					}
				}
				
			},
			(Tuple3<Integer, Integer, Integer> tuple1, Tuple3<Integer, Integer, Integer> tuple2) -> {
				return new Tuple3<Integer, Integer, Integer>(tuple1._1() + tuple2._1(), tuple1._2() + tuple2._2(), tuple1._3() + tuple2._3());
			});
		
		System.out.println(nodeCounts.collect());
		// nodeCounts.foreach(data -> {
		// 	System.out.println("Node1= "+data._1() + " UserNum= " + data._2()._1() + " CategoryNum= " + data._2()._2() + " ArticleNum= " + data._2()._3());
		// });


		//after join: node1 -> (node2 <-> (node1UserCount, node1CategoryCount, node1ArticleCount))
		//after mapToPair: node1 -> (node2, edgeWeight)
		JavaPairRDD<Node, Tuple2<Node, Double>> edgeTransferRDD = allEdges.join(nodeCounts)
			.mapToPair(item -> {
				int node1UserCount = item._2()._2()._1();
				int node1CategoryCount = item._2()._2()._2();
				int node1ArticleCount = item._2()._2()._3();
				Double weight;
				switch (item._1().getType()) {
					case "User": {
						switch (item._2()._1().getType()) {
							case "User": {
								//at least one user to user
								int denom = node1UserCount;
								if (node1CategoryCount == 0 && node1ArticleCount == 0) {
									weight = 1.0 / denom;
								} else if (node1ArticleCount == 0) { //node1CategoryCount != 0
									weight = 0.5 / denom;
								} else if (node1CategoryCount == 0) { //node1ArticleCount != 0
									weight = 0.4286 / denom;
								} else { //both != 0
									weight = 0.3 / denom;
								}
								break;
							}
		
							case "Category": {
								//at least one user to category
								int denom = node1CategoryCount;
								if (node1UserCount == 0 && node1ArticleCount == 0) {
									weight = 1.0 / denom;
								} else if (node1ArticleCount == 0) { //node1UserCount != 0
									weight = 0.5 / denom;
								} else if (node1UserCount == 0) { //node1ArticleCount != 0
									weight = 0.4286 / denom;
								} else { //both != 0
									weight = 0.3 / denom;
								}
								break;
							}
							
							case "Article": {
								//at least one user to article
								int denom = node1ArticleCount;
								if (node1UserCount == 0 && node1CategoryCount == 0) {
									weight = 1.0 / denom;
								} else if (node1CategoryCount == 0) { //node1UserCount != 0
									weight = 0.5714 / denom;
								} else if (node1UserCount == 0) { //node1CategoryCount != 0
									weight = 0.5714 / denom;
								} else { //both != 0
									weight = 0.4 / denom;
								}
								break;
							}
		
							default: {
								throw new IllegalArgumentException("Invalid node type");
							}
						}
						break;
					}

					case "Category": {
						switch (item._2()._1().getType()) {
							case "User": {
								//at least one category to user
								int denom = node1UserCount;
								if (node1ArticleCount == 0) {
									weight = 1.0 / denom;
								} else {
									weight = 0.5 / denom;
								}
								break;
							}
							
							case "Article": {
								//at least one category to article
								int denom = node1ArticleCount;
								if (node1UserCount == 0) {
									weight = 1.0 / denom;
								} else {
									weight = 0.5 / denom;
								}
								break;
							}
		
							default: {
								throw new IllegalArgumentException("Invalid node type");
							}
						}
						break;
					}
					
					case "Article": {
						switch (item._2()._1().getType()) {
							case "User": {
								//at least one article to user
								int denom = node1UserCount;
								if (node1CategoryCount == 0) {
									weight = 1.0 / denom;
								} else {
									weight = 0.5 / denom;
								}
								break;
							}

							case "Category": {
								//at least one article to category
								int denom = node1CategoryCount;
								if (node1UserCount == 0) {
									weight = 1.0 / denom;
								} else {
									weight = 0.5 / denom;
								}
								break;
							}
		
							default: {
								throw new IllegalArgumentException("Invalid node type");
							}
						}
						break;
					}

					default: {
						throw new IllegalArgumentException("Invalid node type");
					}
				}
				return new Tuple2<Node, Tuple2<Node,Double>>(item._1(), new Tuple2<Node, Double>(item._2()._1(), weight));
			});

		//userNode -> (nodeTag, 1.0 starting weight)
		//get all unique users that have edges coming out
		JavaPairRDD<Node, Tuple2<Node, Double>> adsorptionWeights = allEdges.keys()
			.filter((node) -> node.getType().equals("User"))
			.distinct()
			.mapToPair((user) -> new Tuple2<Node, Tuple2<Node, Double>>(user, new Tuple2<Node, Double>(user, 1.0)));
		
		for (int i = 0; i < 15; i++) {
			System.out.println("Iteration: " + i);
			//after join: node1 -> (node2, edge weight), (nodeTag, adsorption weight)
			//after all: node2 -> (nodeTag, adsorption weight * edge weight)
			JavaPairRDD<Node, Tuple2<Node, Double>> propogateRDD = edgeTransferRDD.join(adsorptionWeights)
				.mapToPair((item) -> new Tuple2<Node, Tuple2<Node, Double>>(item._2()._1()._1(),
					new Tuple2<Node, Double>(item._2()._2()._1(), item._2()._1()._2() * item._2()._2()._2())));
			
			// System.out.println(propogateRDD.collect());

			//maptoPair: (node1, node2) -> (sum, count)
			JavaPairRDD<Node, Tuple2<Node, Double>> adsorptionWeights2 = propogateRDD
				.mapToPair((item) -> {
					if (item._1().getType().equals("User") && item._1().equals(item._2()._1())) {
						//check if user has its own tag, set to 1.0 to avoid washout
						return new Tuple2<Tuple2<Node, Node>, Tuple2<Double, Integer>>(
							new Tuple2<Node, Node>(item._1(), item._2()._1()), 
							new Tuple2<Double, Integer>(1.0, 1));
					} else {
						return new Tuple2<Tuple2<Node, Node>, Tuple2<Double, Integer>>(
							new Tuple2<Node, Node>(item._1(), item._2()._1()), 
							new Tuple2<Double, Integer>(item._2()._2(), 1));
					}
					
				})
				.reduceByKey((a, b) -> new Tuple2<Double, Integer>(a._1() + b._1(), a._2() + b._2()))
				.mapToPair((item) -> new Tuple2<Node, Tuple2<Node, Double>>(
					item._1()._1(),
					new Tuple2<Node, Double>(item._1()._2(), item._2()._1() / item._2()._2())));
			
			//add filter for very small values to make it run faster
			adsorptionWeights = adsorptionWeights2;
		}

		adsorptionWeights = adsorptionWeights.filter((tuple) -> tuple._1().getType().equals("Article") && tuple._2()._1().getType().equals("User"));
		//write to database
		List<Item> batchItemsAdsorptionWeights = new ArrayList<Item>();
		adsorptionWeights.collect().stream().forEach((tuple) -> {
			Item item = new Item()
				.withPrimaryKey("username", tuple._2()._1().getId(), "article", tuple._1().getId())
				.withDouble("weight", tuple._2()._2())
				.withBoolean("recommended", false);
			batchItemsAdsorptionWeights.add(item);
			if (batchItemsAdsorptionWeights.size() > 22) {
				TableWriteItems newsArticlesSuggestionTableWriteItems = new TableWriteItems("news_articles_suggestions")
					.withItemsToPut(batchItemsAdsorptionWeights);
				db.batchWriteItem(newsArticlesSuggestionTableWriteItems);
				batchItemsAdsorptionWeights.clear();
			}
		});
		if (!batchItemsAdsorptionWeights.isEmpty()) {
			TableWriteItems tableWriteItems = new TableWriteItems("news_articles_suggestions")
					.withItemsToPut(batchItemsAdsorptionWeights);
			db.batchWriteItem(tableWriteItems);
		}
		return 0;
	}

	/**
	 * Graceful shutdown
	 */
	// public void shutdown() {
	// 	logger.info("Shutting down");
		
	// 	DynamoConnector.shutdown();
		
	// 	if (spark != null)
	// 		spark.close();
	// }
	
	// public static void main(String[] args) {
	// 	final LoadNetworkJob ln = new LoadNetworkJob();

	// 	try {
	// 		ln.initialize();

	// 		ln.run();
	// 	} catch (final IOException ie) {
	// 		logger.error("I/O error: ");
	// 		ie.printStackTrace();
	// 	} catch (final DynamoDbException e) {
	// 		e.printStackTrace();
	// 	} catch (final InterruptedException e) {
	// 		e.printStackTrace();
	// 	} finally {
	// 		ln.shutdown();
	// 	}
	// }
	@Override
	public Integer call(JobContext arg0) throws Exception {
		initialize();
		return run();
	}

}
